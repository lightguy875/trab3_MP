#include <iostream>
using namespace std;

/*
 Test program for principal program
 it will test the main program called Principal.cpp
*/
int main(int argc, char const *argv[])
{
    //*printing function

    //*print function

    /*// testing */

    cout << "Hello, World!";
    // next line comentary \
    it will treat the next line as a commented line \
    yeah
    return 0;
}
