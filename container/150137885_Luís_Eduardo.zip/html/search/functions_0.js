var searchData=
[
  ['count_5fcoment',['count_coment',['../reader_8hpp.html#a09d2f37aca5ab1c62628ea86e6c06f6a',1,'count_coment(fstream *inFile, int &amp;line):&#160;reader.cpp'],['../reader_8cpp.html#a09d2f37aca5ab1c62628ea86e6c06f6a',1,'count_coment(fstream *inFile, int &amp;line):&#160;reader.cpp']]],
  ['count_5fdoc_5flines',['count_doc_lines',['../reader_8hpp.html#af755d33e8dda19017549ff7e9ff9e234',1,'count_doc_lines(fstream *inFile, int &amp;line):&#160;reader.cpp'],['../reader_8cpp.html#af755d33e8dda19017549ff7e9ff9e234',1,'count_doc_lines(fstream *inFile, int &amp;line):&#160;reader.cpp']]]
];
