var searchData=
[
  ['count_5fcoment',['count_coment',['../reader_8hpp.html#a09d2f37aca5ab1c62628ea86e6c06f6a',1,'count_coment(fstream *inFile, int &amp;line):&#160;reader.cpp'],['../reader_8cpp.html#a09d2f37aca5ab1c62628ea86e6c06f6a',1,'count_coment(fstream *inFile, int &amp;line):&#160;reader.cpp']]],
  ['count_5fdoc_5flines',['count_doc_lines',['../reader_8hpp.html#af755d33e8dda19017549ff7e9ff9e234',1,'count_doc_lines(fstream *inFile, int &amp;line):&#160;reader.cpp'],['../reader_8cpp.html#af755d33e8dda19017549ff7e9ff9e234',1,'count_doc_lines(fstream *inFile, int &amp;line):&#160;reader.cpp']]],
  ['contador_20de_20linhas_20de_20código_20c_2fc_2b_2b_20com_20framework_20de_20teste_20gtest',['Contador de linhas de código c/c++ com framework de teste gtest',['../index.html',1,'']]]
];
