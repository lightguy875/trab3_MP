var searchData=
[
  ['test',['TEST',['../_test__reader_8cpp.html#a2f66649dcbd375d1323d7544605a307c',1,'TEST(Reading_file_successfully, reading):&#160;Test_reader.cpp'],['../_test__reader_8cpp.html#af0fe0a120aa61eb3136d466dcfe7e906',1,'TEST(GET_ALL_DOC_LINES, all_lines_count):&#160;Test_reader.cpp'],['../_test__reader_8cpp.html#a466a7bb6532e0919f00e58e3bb948ba0',1,'TEST(find_comment_in_a_file, commenttary):&#160;Test_reader.cpp']]]
];
