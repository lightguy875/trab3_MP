var indexSectionsWithContent =
{
  0: "cmprt",
  1: "prt",
  2: "cmrt",
  3: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Arquivos",
  2: "Funções",
  3: "Páginas"
};

